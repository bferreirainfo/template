package business.usuario;

import infra.filter.PagedFilterHelper;

public class UsuarioFilter extends PagedFilterHelper<Usuario> {

}
