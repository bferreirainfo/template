-- Scripts de carga inicial da base

-- Exemplo
INSERT INTO ARTR.TBNIVEL_HIERARQ VALUES (1, 'Gerente Geral', CURRENT TIMESTAMP);
